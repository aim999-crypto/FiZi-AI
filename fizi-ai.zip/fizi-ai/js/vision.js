// On-device only. Uses FaceDetector if the WebView has it, else falls back to motion tracking (NOT identity/object recognition).
const Vision={on:false,mode:'none',fd:null,prev:null,seenAt:0,
 async start(video,cb){try{const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:160,height:120},audio:false});video.srcObject=s;await video.play();this.s=s;this.on=true;this.cb=cb;
  try{this.fd=new FaceDetector({fastMode:true,maxDetectedFaces:1});this.mode='face'}catch(e){this.mode='motion'}
  this.c=document.createElement('canvas');this.c.width=32;this.c.height=24;this.x=this.c.getContext('2d',{willReadFrequently:true});this.v=video;this.tick();return true}catch(e){return false}},
 stop(){this.on=false;this.s&&this.s.getTracks().forEach(t=>t.stop())},
 async tick(){if(!this.on)return;let p=null;
  try{if(this.fd){const f=await this.fd.detect(this.v);if(f[0]){const b=f[0].boundingBox;p=[1-2*(b.x+b.width/2)/this.v.videoWidth,2*(b.y+b.height/2)/this.v.videoHeight-1]}}
  else{this.x.drawImage(this.v,0,0,32,24);const d=this.x.getImageData(0,0,32,24).data,g=[];let sx=0,sy=0,n=0;
   for(let i=0;i<768;i++)g[i]=d[i*4]*.3+d[i*4+1]*.6+d[i*4+2]*.1;
   if(this.prev)for(let i=0;i<768;i++)if(Math.abs(g[i]-this.prev[i])>28){sx+=i%32;sy+=(i/32|0);n++}
   this.prev=g;if(n>12)p=[1-2*(sx/n)/32,2*(sy/n)/24-1]}}catch(e){}
  if(p){this.seenAt=Date.now()}this.cb(p,this.seenAt);setTimeout(()=>this.tick(),160)}};
