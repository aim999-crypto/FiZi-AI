const Voice={SR:window.SpeechRecognition||window.webkitSpeechRecognition,
 listen(lang,onText,onErr){if(!this.SR){onErr('Speech recognition is not supported here.');return}
  const r=new this.SR();r.lang=lang=='bn'?'bn-BD':'en-US';r.onresult=e=>onText(e.results[0][0].transcript);r.onerror=e=>onErr(e.error=='not-allowed'?'Microphone permission denied.':e.error);r.start();return r},
 speak(t,lang,onEnd){if(!('speechSynthesis' in window))return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang=lang=='bn'?'bn-BD':'en-US';u.onend=onEnd;speechSynthesis.speak(u)},
 stop(){speechSynthesis.cancel()}};
