const Mem={db:null,open(){return new Promise((res,rej)=>{const r=indexedDB.open('fizi',1);r.onupgradeneeded=()=>r.result.createObjectStore('kv');r.onsuccess=()=>{this.db=r.result;res()};r.onerror=()=>rej(r.error)})},
 _s(m){return this.db.transaction('kv',m).objectStore('kv')},
 get(k){return new Promise(r=>{const q=this._s('readonly').get(k);q.onsuccess=()=>r(q.result);q.onerror=()=>r()})},
 set(k,v){return new Promise(r=>{const q=this._s('readwrite').put(v,k);q.onsuccess=()=>r()})},
 del(k){return new Promise(r=>{const q=this._s('readwrite').delete(k);q.onsuccess=()=>r()})},
 all(){return new Promise(r=>{const o={},q=this._s('readonly').openCursor();q.onsuccess=()=>{const c=q.result;if(c){o[c.key]=c.value;c.continue()}else r(o)}})},
 clear(){return new Promise(r=>{const q=this._s('readwrite').clear();q.onsuccess=()=>r()})}};
