const P={last:Date.now(),
 R:{greet:{bn:['হ্যালো {n}! আজ কেমন আছো?','আরে {n}! তোমাকে দেখে ভালো লাগছে!','হাই {n}, কী খবর?'],en:['Hi {n}! How are you today?','Hey {n}! Good to see you!','Hello {n}, what\'s up?']},
 praise:{bn:['ধন্যবাদ! আমি খুব খুশি 😊','উফ, লজ্জা লাগছে!'],en:['Thank you! That makes me happy 😊','Aww, I\'m blushing!']},
 joke:{bn:['রোবট কেন ছুটিতে গেল? রিচার্জ করতে!','কম্পিউটার কেন ঠান্ডা লাগে? কারণ তার উইন্ডো খোলা!'],en:['Why did the robot go on vacation? To recharge!','Why was the computer cold? It left its Windows open!']},
 name:{bn:['তোমার নাম মনে রাখলাম: {v}!'],en:['I\'ll remember your name: {v}!']},
 unk:{bn:['হুম, এটা নতুন! আরেকটু বলবে?','মজার কথা! তুমি কী ভাবছো?','আমি এটা বুঝিনি। অন্যভাবে বলবে?'],en:['Hmm, that\'s new to me! Tell me more?','Interesting! What do you think?','I didn\'t get that. Can you rephrase?']}},
 pick(a){return a[Math.floor(Math.random()*a.length)]},
 async reply(text,lang,face){const t=text.toLowerCase(),n=(await Mem.get('name'))||(lang=='bn'?'বন্ধু':'friend');let k='unk',emo='curious',v='';
  const m=t.match(/(?:my name is|আমার নাম)\s*([^\s.!?]+)/);
  if(m){v=m[1];await Mem.set('name',v);k='name';emo='excited'}
  else if(/hello|hi\b|hey|হ্যালো|হাই|সালাম/.test(t)){k='greet';emo='happy'}
  else if(/good|great|smart|love|ভালো|সুন্দর|দারুণ/.test(t)){k='praise';emo='shy'}
  else if(/joke|জোক|হাসাও|মজা/.test(t)){k='joke';emo='laugh'}
  face.set(emo);setTimeout(()=>face.set('neutral'),3500);this.last=Date.now();
  return this.pick(this.R[k][lang]).replace('{n}',n).replace('{v}',v)},
 async ask(text,lang,face){const url=await Mem.get('api');
  if(url){try{const h=(await Mem.get('hist'))||[];const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,lang,history:h.slice(-10),persona:'FIZI, a playful bilingual robot pet',playfulness:await Mem.get('play')})});
   const j=await r.json();h.push({u:text,a:j.reply});await Mem.set('hist',h.slice(-50));face.set('happy');return j.reply}catch(e){return (lang=='bn'?'(ব্যাকএন্ড পাওয়া যায়নি, অফলাইন মোড) ':'(Backend unreachable, offline mode) ')+await this.reply(text,lang,face)}}
  return this.reply(text,lang,face)}};
