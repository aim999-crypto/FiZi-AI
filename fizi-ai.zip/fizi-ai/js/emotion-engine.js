const EMO={neutral:{o:1,lt:0,lb:0,c:'#22e5ff'},happy:{o:.9,lt:0,lb:.45,c:'#3dffb0'},sad:{o:.8,lt:-.7,lb:0,c:'#6ea8ff',tear:1},
angry:{o:.8,lt:.8,lb:0,c:'#ff4d6d'},sleepy:{o:.2,lt:0,lb:0,c:'#8a7bff'},curious:{o:1.1,lt:0,lb:0,c:'#ffd24d',asym:1},
surprised:{o:1.3,lt:0,lb:0,c:'#ffffff',w:.7},excited:{o:1.1,lt:0,lb:.35,c:'#ff7bf0',shake:1},shy:{o:.6,lt:-.3,lb:.2,c:'#ff9ac8',look:[-.6,.5]},
sleep:{o:.04,lt:0,lb:0,c:'#6a5acd'},cry:{o:.7,lt:-.8,lb:0,c:'#6ea8ff',tear:2,shake:1},laugh:{o:.35,lt:0,lb:.6,c:'#3dffb0',shake:1}};
const COLORS=['#22e5ff','#9b5cff','#3dffb0','#ffd24d','#ff7bf0','#ff4d6d'];
class Face{
 constructor(cv){this.cv=cv;this.x=cv.getContext('2d');this.cur={...EMO.neutral,w:1};this.tgt={...EMO.neutral,w:1};this.look=[0,0];this.lt=[0,0];this.blink=0;this.nb=performance.now()+2500;this.tear=0;this.shake=0;this.t=0;requestAnimationFrame(()=>this.loop());}
 set(name,opt={}){const e=EMO[name]||EMO.neutral;this.tgt={w:1,lb:0,lt:0,asym:0,...e,c:opt.color||e.c};this.tear=e.tear||0;this.shake=e.shake||0;if(e.look)this.lt=e.look;else if(opt.look)this.lt=opt.look;}
 gaze(x,y){this.lt=[x,y]}
 loop(){const n=performance.now(),c=this.cur,g=this.tgt;this.t=n/1000;
  for(const p of['o','lt','lb','w'])c[p]+=(g[p]-c[p])*.15;c.c=g.c;c.asym=g.asym;
  if(n>(this.ns||0)){this.ns=n+700+Math.random()*2200;this.j=[(Math.random()-.5)*.25,(Math.random()-.5)*.2]}const j=this.j||[0,0];this.look[0]+=(this.lt[0]+j[0]-this.look[0])*.18;this.look[1]+=(this.lt[1]+j[1]-this.look[1])*.18;
  if(n>this.nb){this.blink=1;if(Math.random()<.2)this.nb=n+250;else this.nb=n+2000+Math.random()*3500}this.blink=Math.max(0,this.blink-.12);
  this.draw();this.x.restore();requestAnimationFrame(()=>this.loop());}
 draw(){const x=this.x,W=this.cv.width,c=this.cur;const H=this.cv.height;x.clearRect(0,0,W,H);x.save();x.translate(W/2,H/2);const br=1+Math.sin(this.t*1.6)*.02;x.scale(1.25*br,1.25*br);x.translate(-W/2,-H/2);
  const bob=Math.sin(this.t*2)*4,sh=this.shake?Math.sin(this.t*40)*3:0,bl=1-Math.sin(Math.min(1,this.blink)*Math.PI);
  [-1,1].forEach(s=>{const w=70*c.w,hh=110*c.o*bl*(c.asym&&s>0?.7:1),cx=W/2+s*80+this.look[0]*25+sh,cy=H/2-10+this.look[1]*20+bob;if(hh<4)return;
   x.save();x.shadowColor=c.c;x.shadowBlur=30;x.fillStyle=c.c;x.beginPath();x.roundRect(cx-w/2,cy-hh/2,w,hh,Math.min(w,hh)/2.4);x.clip();x.fillRect(cx-w,cy-hh,w*2,hh*2);
   x.shadowBlur=0;x.fillStyle='#0b1230';
   const cut=hh*.5*Math.abs(c.lt),inner=c.lt>0?cut:0,outer=c.lt>0?0:cut,ci=s<0?inner:outer,co=s<0?outer:inner;
   x.beginPath();x.moveTo(cx-w,cy-hh);x.lineTo(cx+w,cy-hh);x.lineTo(cx+w/2,cy-hh/2+(s<0?ci:co)*(s<0?1:1));x.lineTo(cx-w/2,cy-hh/2+(s<0?co:ci));x.fill();
   if(c.lb>.02){x.beginPath();x.ellipse(cx,cy+hh/2+10,w,hh*c.lb*.9,0,0,7);x.fill()}
   x.fillStyle='rgba(255,255,255,.5)';x.beginPath();x.arc(cx-w*.18,cy-hh*.28,w*.09,0,7);x.fill();x.restore();
   if(this.tear){x.fillStyle='#8fd3ff';x.beginPath();x.arc(cx+s*10,cy+hh/2+((this.t*60*this.tear)%50),6,0,7);x.fill()}});
 }}
